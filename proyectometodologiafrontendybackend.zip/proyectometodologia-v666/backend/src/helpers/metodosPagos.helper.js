export const METODOS_VALIDOS = [
  "tarjeta_credito",
  "tarjeta_debito",
  "transferencia",
  "efectivo",
  "webpay",
];
import { METODOS_VALIDOS } from "./metodosPagos.helper.js";
